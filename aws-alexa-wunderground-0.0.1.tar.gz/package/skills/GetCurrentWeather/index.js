'use strict';

module.exports = require('./getCurrentWeather')